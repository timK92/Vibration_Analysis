# Verta Bioenergy — Crusher Diagnostic System

AI-powered vibration diagnostic tool for the Dasmariñas Cavite hammer mill crusher.

## Deploy to Vercel (5 minutes)

### Option A — GitHub (recommended, no command line needed)

1. Create a free account at github.com
2. Click **New repository** → name it `verta-diagnostic` → Create
3. Click **uploading an existing file** → drag the three files/folder into the page:
   - `index.html`
   - `api/diagnose.js`
   - `vercel.json`
4. Click **Commit changes**
5. Go to vercel.com → **Add New Project** → Import your GitHub repo
6. Click **Deploy** (no build settings needed)
7. Go to **Settings → Environment Variables** → Add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your key from console.anthropic.com
8. **Redeploy** (Deployments tab → Redeploy)
9. Share the URL with your team — they need no setup

### Option B — Vercel CLI (faster if you have Node.js)

```bash
cd verta-diagnostic
npx vercel          # follow prompts, sign up if needed
```

Then set the API key:
```bash
vercel env add ANTHROPIC_API_KEY
# paste your key when prompted, select Production
vercel --prod       # redeploy with the new env var
```

## After deployment

Each team member:
1. Opens the URL
2. Clicks the ⚙ gear icon → Settings
3. Sets their alert email address
4. Optionally sets the machine label

No API key entry needed — it's handled server-side.

## Files

| File | Purpose |
|------|---------|
| `index.html` | Frontend — vibration inputs, blade weights, AI results, history |
| `api/diagnose.js` | Serverless function — proxies Claude API (keeps key server-side) |
| `vercel.json` | Vercel config — sets 30s timeout for the API function |

## Custom domain (optional)

Vercel Dashboard → Your Project → Settings → Domains → Add domain

---

Get API key: https://console.anthropic.com
